// components/landing/before-after-showcase.tsx
// This component displays a section featuring interactive "Before & After" sliders
// to showcase the quality of photo restoration.

import BeforeAfterSlider from "@/components/restoration/before-after-slider" // Custom interactive slider component.

// Defines the data for each before-and-after example.
// Placeholder: In a real application, these image URLs might come from a CMS or storage.
const restorationExamples = [
  {
    before: "/public/images/showcase-scratches-before.jpg",
    after: "/public/images/showcase-scratches-after.png",
    alt: "Photo with scratches",
  },
  {
    before: "/public/images/showcase-magenta-before.jpg",
    after: "/public/images/showcase-scratches-after.png", // Placeholder: Using same after image for demo
    alt: "Photo with magenta cast",
  },
  {
    before: "/public/images/showcase-torn-before.jpg",
    after: "/public/images/showcase-scratches-after.png", // Placeholder: Using same after image for demo
    alt: "Torn photo",
  },
  {
    before: "/public/images/showcase-stained-before.jpg",
    after: "/public/images/showcase-scratches-after.png", // Placeholder: Using same after image for demo
    alt: "Stained photo",
  },
]

export default function BeforeAfterShowcase() {
  return (
    <section className="py-16 md:py-24 bg-brand-background">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-serif font-bold text-center text-brand-text mb-16">
          From Faded to Flawless.
        </h2>
        {/* Grid layout for the interactive sliders. */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-8">
          {restorationExamples.map((example, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <BeforeAfterSlider beforeSrc={example.before} afterSrc={example.after} alt={example.alt} />
              <p className="mt-4 text-lg text-brand-text/80">{example.alt}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
