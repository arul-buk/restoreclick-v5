// Revised components/landing/editorial-hero-section.tsx
import Link from "next/link"
import { buttonVariants } from "@/components/ui/button" // Import buttonVariants
import { cn } from "@/lib/utils" // Import cn utility

export default function EditorialHeroSection() {
  return (
    <section className="py-20 text-center bg-gray-50">
      <div className="container mx-auto">
        <h1 className="text-5xl font-serif font-bold mb-6 text-brand-text">
          Preserve Your Legacy, One Photo at a Time
        </h1>
        <p className="text-xl text-brand-text/80 mb-10 max-w-2xl mx-auto">
          Our digital artisans meticulously restore your cherished photographs, transforming faded memories into
          timeless treasures.
        </p>
        <Link
          href="/restore-old-photos"
          className={cn(
            buttonVariants({ size: "lg", variant: "default" }), // Apply button styles
            "bg-brand-cta hover:bg-brand-cta/90 text-white font-semibold px-10 py-6 text-lg shadow-soft hover:shadow-soft-md", // Custom/brand styles
          )}
        >
          Start Your Restoration
        </Link>
      </div>
    </section>
  )
}
