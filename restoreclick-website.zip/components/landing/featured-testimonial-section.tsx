// components/landing/featured-testimonial-section.tsx
// This component highlights a single, prominent customer testimonial.
// It features a large quote, customer details, and an accompanying image.

import Image from "next/image" // Next.js Image component for optimized images.
import { Star } from "lucide-react" // Lucide React icon for star ratings.

export default function FeaturedTestimonialSection() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6 max-w-4xl">
        <h2 className="sr-only">Featured Testimonial</h2> {/* Screen reader only heading */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Testimonial content */}
          <div className="text-brand-text">
            <div className="flex mb-4">
              {/* Star rating */}
              {Array(5)
                .fill(0)
                .map((_, i) => (
                  <Star key={i} className="h-6 w-6 text-yellow-400 fill-yellow-400" />
                ))}
            </div>
            <blockquote className="text-3xl md:text-4xl font-serif italic leading-snug mb-6">
              &ldquo;RestoreClick didn't just restore photos; they restored a piece of our family's soul. The attention
              to detail is simply unparalleled.&rdquo;
            </blockquote>
            <p className="text-xl font-semibold text-brand-text">Eleanor & Thomas V.</p>
            <p className="text-brand-text/70">Generations Preserved</p>
          </div>
          {/* Testimonial image */}
          <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden shadow-soft">
            <Image
              src="/public/images/testimonial-couple.jpg" // Static image asset for the testimonial.
              alt="Happy couple looking at a restored photo"
              fill // Fills the parent container.
              className="object-cover" // Ensures image covers the area.
              sizes="(max-width: 768px) 100vw, 50vw" // Image optimization sizes.
            />
          </div>
        </div>
      </div>
    </section>
  )
}
