import { buttonVariants } from "@/components/ui/button" // Import buttonVariants
import { cn } from "@/lib/utils" // Import cn utility
import Link from "next/link"

const HeroSection = () => {
  return (
    <section className="bg-gray-100 py-20">
      <div className="container mx-auto text-center">
        <h1 className="text-5xl font-bold mb-6">Restore Your Precious Memories</h1>
        <p className="text-xl text-gray-700 mb-8">
          Bring your old photos back to life with our professional restoration services.
        </p>
        <Link
          href="/restore-old-photos"
          className={cn(
            buttonVariants({ variant: "default" }), // Apply default button styles
            "shadow-soft hover:shadow-soft-md",
          )}
        >
          Begin Your Restoration
        </Link>
      </div>
    </section>
  )
}

export default HeroSection
