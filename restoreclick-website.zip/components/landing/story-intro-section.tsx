// components/landing/story-intro-section.tsx
// This component provides an introductory section to the brand's story on the homepage.
// It features a headline, descriptive text, an image, and a call to action to learn more.

import Image from "next/image" // Next.js Image component for optimized images.
import { Button } from "@/components/ui/button" // Shadcn UI Button component.

export default function StoryIntroSection() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6 max-w-6xl">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Content for the story introduction. */}
          <div className="text-brand-text">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">Our Story, Your Legacy.</h2>
            <p className="text-lg leading-relaxed mb-4">
              At RestoreClick, we believe every photograph holds an irreplaceable piece of your family's history. Our
              journey began with a passion for preserving these tangible links to the past, transforming faded and
              damaged memories into vibrant, lasting heirlooms.
            </p>
            <p className="text-lg leading-relaxed mb-6">
              We combine the meticulous artistry of digital restoration with a seamless, white-glove service, ensuring
              your cherished moments are safeguarded with precision and care.
            </p>
            {/* Call to action button to read the full story. */}
            <Button
              variant="outline"
              className="border-brand-cta text-brand-cta hover:bg-brand-cta hover:text-white transition-colors"
              asChild // Renders the Button as an anchor tag.
            >
              <a href="/our-story">Discover Our Full Story</a> {/* Link to the dedicated "Our Story" page. */}
            </Button>
          </div>
          {/* Image accompanying the story introduction. */}
          <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden shadow-soft">
            <Image
              src="/public/images/story-intro-photo.jpg" // Static image asset.
              alt="Old family photo being held"
              fill // Fills the parent container.
              className="object-cover" // Ensures image covers the area.
              sizes="(max-width: 768px) 100vw, 50vw" // Image optimization sizes.
            />
          </div>
        </div>
      </div>
    </section>
  )
}
