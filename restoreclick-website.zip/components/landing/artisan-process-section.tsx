// components/landing/artisan-process-section.tsx
// This component details the "Artisan Process" of photo restoration in a visual, step-by-step manner.
// It uses images and descriptive text to explain each stage.

import Image from "next/image" // Next.js Image component for optimized images.

// Defines the data for each step in the artisan process.
const processSteps = [
  {
    title: "1. Initial Assessment & Digitization",
    description:
      "Your precious photographs are carefully assessed for damage, then professionally scanned at high resolution to create a perfect digital working copy.",
    image: "/public/images/artisan-support.jpg", // Static image asset.
    alt: "Artisan assessing a photograph",
  },
  {
    title: "2. Meticulous Digital Restoration",
    description:
      "Our skilled digital artisans meticulously repair tears, remove scratches, correct fading, and restore colors using advanced software, pixel by pixel.",
    image: "/public/images/lily-at-work.jpg", // Static image asset.
    alt: "Artisan working on digital restoration",
  },
  {
    title: "3. Quality Assurance & Enhancement",
    description:
      "Each restored image undergoes rigorous quality checks and final enhancements to ensure museum-quality results, ready for display.",
    image: "/public/images/artisan-team.jpg", // Static image asset.
    alt: "Artisan team reviewing restored photos",
  },
]

export default function ArtisanProcessSection() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-serif font-bold text-center text-brand-text mb-16">
          Our Artisan Process
        </h2>
        <div className="space-y-16">
          {processSteps.map((step, index) => (
            <div
              key={step.title}
              className={`grid md:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? "md:grid-flow-col-dense" : "" // Alternates image/text order.
              }`}
            >
              {/* Image for the step */}
              <div
                className={`relative aspect-[4/3] w-full rounded-lg overflow-hidden shadow-soft ${
                  index % 2 === 1 ? "md:col-start-2" : "" // Puts image on right for odd indices.
                }`}
              >
                <Image
                  src={step.image || "/placeholder.svg"}
                  alt={step.alt}
                  fill // Fills the parent container.
                  className="object-cover" // Ensures image covers the area.
                  sizes="(max-width: 768px) 100vw, 50vw" // Image optimization sizes.
                />
              </div>
              {/* Content for the step */}
              <div className={`${index % 2 === 1 ? "md:col-start-1 md:row-start-1" : ""}`}>
                <h3 className="text-3xl font-serif font-semibold text-brand-text mb-4">{step.title}</h3>
                <p className="text-lg leading-relaxed text-brand-text/80">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
