// components/landing/founder-story-section.tsx
// This component tells the story of the founder, Lily Chen, and the inspiration behind RestoreClick.
// It features an image of the founder and a narrative text.

import Image from "next/image" // Next.js Image component for optimized images.
import { Button } from "@/components/ui/button" // Shadcn UI Button component.

export default function FounderStorySection() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6 max-w-6xl">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image of the founder */}
          <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden shadow-soft">
            <Image
              src="/public/images/lily-founder.jpg" // Static image asset for Lily, the founder.
              alt="Lily Chen, Founder of RestoreClick"
              fill // Fills the parent container.
              className="object-cover" // Ensures image covers the area.
              sizes="(max-width: 768px) 100vw, 50vw" // Image optimization sizes.
            />
          </div>
          {/* Founder's story content */}
          <div className="text-brand-text">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">Our Founder's Vision</h2>
            <p className="text-lg leading-relaxed mb-4">
              RestoreClick was founded by Lily Chen, a digital artisan with a deep passion for preserving family
              legacies. Growing up, Lily cherished her grandmother's photo albums, filled with faded and damaged
              snapshots of a bygone era. She realized the profound emotional value held within these tangible memories
              and the urgent need to safeguard them for future generations.
            </p>
            <p className="text-lg leading-relaxed mb-6">
              Driven by this personal connection, Lily combined her artistic eye with cutting-edge digital restoration
              techniques to create RestoreClick. Her vision was to offer a white-glove service that makes the process of
              preserving cherished photographs effortless and accessible, ensuring every memory is meticulously restored
              to museum-quality perfection.
            </p>
            {/* Call to action to learn more about the story. */}
            <Button
              variant="outline"
              className="border-brand-cta text-brand-cta hover:bg-brand-cta hover:text-white transition-colors"
              asChild
            >
              <a href="/our-story">Read Our Full Story</a> {/* Link to the dedicated "Our Story" page. */}
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
