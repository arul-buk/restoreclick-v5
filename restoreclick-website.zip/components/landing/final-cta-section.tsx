// components/landing/final-cta-section.tsx
// This component provides a final call to action section, typically placed at the bottom of a page.
// It features a headline, descriptive text, and a button to encourage user engagement.
// NOTE: This component might be an older version or a generic one,
// as `gentle-invitation-section.tsx` is specifically used in `app/page.tsx`.

import { buttonVariants } from "@/components/ui/button" // Import buttonVariants
import { cn } from "@/lib/utils" // Import cn utility
import Link from "next/link"

export default function FinalCtaSection() {
  return (
    <section className="py-16 md:py-24 bg-brand-text text-white text-center">
      <div className="container mx-auto px-6 max-w-3xl">
        <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">Ready to Restore Your Memories?</h2>
        <p className="text-lg leading-relaxed mb-10">
          Don't let precious moments fade away. Begin your effortless restoration journey with RestoreClick today.
        </p>
        <Link
          href="/restore-old-photos"
          className={cn(
            buttonVariants({ size: "lg", variant: "default" }), // Apply default button styles
            "bg-brand-cta hover:bg-brand-cta/90 text-white font-semibold px-10 py-6 text-lg shadow-soft-md hover:shadow-soft-lg transition-shadow",
          )}
        >
          Start Your Restoration
        </Link>
      </div>
    </section>
  )
}
