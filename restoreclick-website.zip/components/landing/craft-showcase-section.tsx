import BeforeAfterShowcase from "./before-after-showcase" // Component displaying interactive sliders.

const showcaseItems = [
  {
    id: 1,
    beforeSrc: "/images/showcase-folded-before.jpg",
    afterSrc: "/images/showcase-folded-after.png",
    title: "The Birthday Memory, 1970s",
    description:
      "A cherished childhood birthday photo, once severely folded and discolored, now perfectly seamless and vibrant.",
  },
  {
    id: 2,
    beforeSrc: "/images/showcase-stained-before.jpg",
    afterSrc: "/images/showcase-stained-after.png",
    title: "The Wedding Day, 1960",
    description:
      "A beautiful wedding portrait, rescued from significant staining and brought back to its pristine elegance.",
  },
  {
    id: 3,
    beforeSrc: "/images/showcase-torn-before.jpg",
    afterSrc: "/images/showcase-torn-after.png",
    title: "The Family Portrait, 1965",
    description: "A beloved family portrait, once torn and taped, now seamlessly repaired and reunited.",
  },
]

export default function CraftShowcaseSection() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-brand-text mb-6">
            The Craft of Transformation
          </h2>
          <p className="text-xl text-brand-text/80 max-w-2xl mx-auto leading-relaxed">
            Witness the meticulous artistry that brings your faded memories back to life. Our interactive showcase
            reveals the stunning difference.
          </p>
        </div>
        {/* Integrates the BeforeAfterShowcase component to display the interactive sliders. */}
        <BeforeAfterShowcase items={showcaseItems} />
      </div>
    </section>
  )
}
