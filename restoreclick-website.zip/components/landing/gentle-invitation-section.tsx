import Link from "next/link"
// components/landing/gentle-invitation-section.tsx
// This component serves as a final call to action on the homepage.
// It features a compelling headline, an image, and a button to initiate the restoration process.

import Image from "next/image" // Next.js Image component for optimized images.
import { buttonVariants } from "@/components/ui/button" // Shadcn UI Button component, import buttonVariants
import { cn } from "@/lib/utils" // Import cn utility

export default function GentleInvitationSection() {
  return (
    <section className="py-16 md:py-24 bg-brand-background">
      <div className="container mx-auto px-6 max-w-6xl">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image of a woman with a restored photo, emphasizing the result of the service. */}
          <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden shadow-soft">
            <Image
              src="/public/images/woman-with-restored-photo.jpg" // Static image asset.
              alt="Woman holding a beautifully restored photograph"
              fill // Fills the parent container.
              className="object-cover" // Ensures image covers the area.
              sizes="(max-width: 768px) 100vw, 50vw" // Image optimization sizes.
            />
          </div>
          {/* Content for the call to action. */}
          <div className="text-brand-text">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">Preserve What Matters Most.</h2>
            <p className="text-lg leading-relaxed mb-8">
              Your family's memories are irreplaceable. Entrust them to RestoreClick's digital artisans and transform
              faded moments into timeless heirlooms. Begin your journey to perfectly preserved memories today.
            </p>
            {/* Call to action button. */}
            <Link
              href="/restore-old-photos"
              className={cn(
                buttonVariants({ size: "lg", variant: "default" }), // Apply default button styles
                "bg-brand-cta hover:bg-brand-cta/90 text-white font-semibold px-10 py-6 text-lg",
              )}
            >
              Entrust Us With Your Memories {/* Link to the photo upload page. */}
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
