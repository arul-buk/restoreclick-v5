// components/restoration/email-confirmation-modal.tsx
// This component defines a placeholder modal for email confirmation.
// It simulates the process of collecting a user's email to send download links,
// serving as a temporary stand-in until a full email integration (e.g., SendGrid)
// or authentication flow (e.g., Clerk) is implemented.

"use client" // Marks this component as a Client Component due to state and interactivity.

import { useState } from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog" // Shadcn UI Alert Dialog components.
import { Input } from "@/components/ui/input" // Shadcn UI Input component.
import { Button } from "@/components/ui/button" // Shadcn UI Button component.

// Defines the props for the EmailConfirmationModal component.
interface EmailConfirmationModalProps {
  isOpen: boolean // Controls the visibility of the modal.
  onClose: () => void // Callback function to close the modal.
  onConfirm: (email: string) => void // Callback function when email is confirmed.
  downloadType: "all" | "single" // Indicates if it's for all photos or a single one.
}

export default function EmailConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  downloadType,
}: EmailConfirmationModalProps) {
  const [email, setEmail] = useState("") // State to store the entered email address.
  const [error, setError] = useState<string | null>(null) // State to store validation errors.

  // Handles the confirmation action when the user clicks "Confirm".
  const handleConfirm = () => {
    if (!email || !email.includes("@") || !email.includes(".")) {
      setError("Please enter a valid email address.") // Basic email validation.
      return
    }
    setError(null) // Clear any previous errors.
    onConfirm(email) // Call the onConfirm callback with the entered email.
    setEmail("") // Clear the email input after confirmation.
    onClose() // Close the modal.
  }

  // Handles closing the modal.
  const handleClose = () => {
    setEmail("") // Clear email on close.
    setError(null) // Clear errors on close.
    onClose() // Call the onClose callback.
  }

  return (
    <AlertDialog open={isOpen} onOpenChange={handleClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Confirm Your Email for Download</AlertDialogTitle>
          <AlertDialogDescription>
            {/* Dynamic description based on download type */}
            Please enter your email address to receive the download link for your{" "}
            {downloadType === "all" ? "restored collection" : "restored photo"}.
            <br />
            <span className="font-semibold text-brand-cta">
              {/* Placeholder Handoff: */}
              {/* In a real application, this email would be used to send the actual download links. */}
              {/* This modal is a placeholder for a full authentication/email delivery system. */}
              This is a placeholder for email collection. No actual email will be sent.
            </span>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="grid gap-4 py-4">
          <Input
            id="email"
            type="email"
            placeholder="your.email@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="col-span-3"
          />
          {error && <p className="text-red-500 text-sm mt-1">{error}</p>} {/* Display validation error */}
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel asChild>
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
          </AlertDialogCancel>
          <AlertDialogAction asChild>
            <Button onClick={handleConfirm}>Confirm</Button>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
