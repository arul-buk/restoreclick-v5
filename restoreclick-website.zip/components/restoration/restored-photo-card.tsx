import type React from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { buttonVariants } from "@/components/ui/button" // Import buttonVariants
import { cn } from "@/lib/utils" // Import cn utility
import Link from "next/link"

interface RestoredPhotoCardProps {
  photo: {
    id: string
    title: string
    description: string
    imageUrl: string
  }
}

const RestoredPhotoCard: React.FC<RestoredPhotoCardProps> = ({ photo }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{photo.title}</CardTitle>
        <CardDescription>{photo.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <img src={photo.imageUrl || "/placeholder.svg"} alt={photo.title} className="w-full h-auto rounded-md" />
      </CardContent>
      <CardFooter className="flex justify-end">
        <Link
          href={`/restore-old-photos?view=${photo.id}`}
          className={cn(
            buttonVariants({ variant: "link" }), // Apply link button styles
            "text-brand-accent",
          )}
        >
          View Details
        </Link>
      </CardFooter>
    </Card>
  )
}

export default RestoredPhotoCard
