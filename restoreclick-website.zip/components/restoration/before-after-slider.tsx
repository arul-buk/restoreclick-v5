"use client"

import type React from "react"
import { useState, useRef, useEffect, useCallback } from "react"
import Image from "next/image"
import { GripVertical } from "lucide-react"

interface BeforeAfterSliderProps {
  beforeSrc: string
  afterSrc: string
  alt: string
}

export default function BeforeAfterSlider({ beforeSrc, afterSrc, alt }: BeforeAfterSliderProps) {
  const [sliderPosition, setSliderPosition] = useState(50) // 0-100 percentage
  const containerRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)

  const handleMouseMove = useCallback(
    (e: MouseEvent | TouchEvent) => {
      if (!isDragging || !containerRef.current) return

      const { left, width } = containerRef.current.getBoundingClientRect() // Get container's position and width.
      let clientX = (e as MouseEvent).clientX // Default to mouse clientX.

      // Adjust for touch events if the event type is touchmove.
      if (e.type === "touchmove" && (e as TouchEvent).touches) {
        clientX = (e as TouchEvent).touches[0].clientX
      }

      // Calculate new position as a percentage of the container width.
      let newPosition = ((clientX - left) / width) * 100
      // Clamp the position between 0 and 100 to keep it within bounds.
      newPosition = Math.max(0, Math.min(100, newPosition))
      setSliderPosition(newPosition) // Update slider position state.
    },
    [isDragging], // Dependency: re-create if isDragging changes.
  )

  // Callback function to handle mouse/touch release, ending the drag.
  const handleMouseUp = useCallback(() => {
    setIsDragging(false) // Set dragging state to false.
  }, [])

  // Callback function to handle mouse/touch down, starting the drag.
  const handleMouseDown = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true) // Set dragging state to true.
    e.preventDefault() // Prevent default browser behavior (e.g., image dragging, text selection).
  }, [])

  // useEffect hook to add and remove global event listeners for dragging.
  useEffect(() => {
    if (isDragging) {
      // Add event listeners when dragging starts.
      window.addEventListener("mousemove", handleMouseMove)
      window.addEventListener("mouseup", handleMouseUp)
      window.addEventListener("touchmove", handleMouseMove, { passive: false }) // passive: false for preventDefault
      window.addEventListener("touchend", handleMouseUp)
    } else {
      // Remove event listeners when dragging stops.
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseup", handleMouseUp)
      window.removeEventListener("touchmove", handleMouseMove)
      window.removeEventListener("touchend", handleMouseUp)
    }

    // Cleanup function: remove event listeners when component unmounts or isDragging changes.
    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseup", handleMouseUp)
      window.removeEventListener("touchmove", handleMouseMove)
      window.removeEventListener("touchend", handleMouseUp)
    }
  }, [isDragging, handleMouseMove, handleMouseUp]) // Dependencies: re-run if these change.

  return (
    <div
      ref={containerRef} // Attach ref to the container.
      className="relative w-full aspect-[4/3] overflow-hidden rounded-lg shadow-soft cursor-ew-resize group"
      onMouseDown={handleMouseDown} // Start drag on mouse down.
      onTouchStart={handleMouseDown} // Start drag on touch start.
    >
      {/* Before Image: Always visible, covers the full container. */}
      <Image
        src={beforeSrc || "/placeholder.svg"} // Use placeholder if src is missing.
        alt={`Before: ${alt}`}
        fill // Fills the parent container.
        className="object-cover select-none" // Ensures image covers, prevents selection.
      />

      {/* After Image: Clipped to show only the portion to the right of the slider. */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }} // CSS clip-path to control visibility.
      >
        <Image
          src={afterSrc || "/placeholder.svg"} // Use placeholder if src is missing.
          alt={`After: ${alt}`}
          fill
          className="object-cover select-none"
        />
      </div>

      {/* Slider Handle: The draggable element. */}
      <div
        className="absolute top-0 bottom-0 w-1 bg-white flex items-center justify-center cursor-ew-resize z-10 transition-colors group-hover:bg-brand-cta"
        style={{ left: `${sliderPosition}%`, transform: "translateX(-50%)" }} // Position based on sliderPosition.
      >
        <div className="w-10 h-10 rounded-full bg-white border-2 border-brand-text/20 flex items-center justify-center shadow-md group-hover:border-brand-cta transition-colors">
          <GripVertical className="h-5 w-5 text-brand-text/70 group-hover:text-brand-cta transition-colors" />{" "}
          {/* Grip icon */}
        </div>
      </div>
    </div>
  )
}
