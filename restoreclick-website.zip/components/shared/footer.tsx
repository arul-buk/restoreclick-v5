// components/shared/footer.tsx
// This component defines the global footer for the RestoreClick website.
// It includes navigation links, contact information, social media links,
// and copyright details, adhering to the brand's minimalist and elegant aesthetic.

import Link from "next/link" // Next.js Link component for internal navigation.
import { Facebook, Instagram, Twitter, Linkedin } from "lucide-react" // Lucide React icons for social media.

export default function Footer() {
  return (
    <footer className="bg-brand-text text-brand-background py-12 md:py-16">
      <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Information */}
        <div className="col-span-1 md:col-span-2">
          <h3 className="font-serif text-3xl font-bold text-white mb-4">RestoreClick</h3>
          <p className="text-brand-background/80 leading-relaxed max-w-md">
            Preserving your legacy, one cherished memory at a time. White-glove digital restoration for your most
            precious family photographs.
          </p>
        </div>

        {/* Navigation Links */}
        <div>
          <h4 className="font-serif text-xl font-semibold text-white mb-4">Quick Links</h4>
          <nav className="space-y-2">
            <Link href="/" className="block text-brand-background/80 hover:text-brand-cta transition-colors">
              Home
            </Link>
            <Link href="/our-story" className="block text-brand-background/80 hover:text-brand-cta transition-colors">
              Our Story
            </Link>
            <Link
              href="/restore-old-photos"
              className="block text-brand-background/80 hover:text-brand-cta transition-colors"
            >
              Restore Photos
            </Link>
            <Link href="/blog" className="block text-brand-background/80 hover:text-brand-cta transition-colors">
              Blog
            </Link>
            <Link href="/contact" className="block text-brand-background/80 hover:text-brand-cta transition-colors">
              Contact
            </Link>
          </nav>
        </div>

        {/* Legal Links */}
        <div>
          <h4 className="font-serif text-xl font-semibold text-white mb-4">Legal</h4>
          <nav className="space-y-2">
            <Link href="/privacy" className="block text-brand-background/80 hover:text-brand-cta transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="block text-brand-background/80 hover:text-brand-cta transition-colors">
              Terms of Service
            </Link>
            <Link href="/faq" className="block text-brand-background/80 hover:text-brand-cta transition-colors">
              FAQ
            </Link>
          </nav>
        </div>
      </div>

      {/* Separator */}
      <div className="container mx-auto px-6 mt-10 pt-8 border-t border-brand-background/20 flex flex-col md:flex-row items-center justify-between text-brand-background/70 text-sm">
        {/* Copyright Information */}
        <p className="mb-4 md:mb-0">&copy; {new Date().getFullYear()} RestoreClick. All rights reserved.</p>

        {/* Social Media Links */}
        <div className="flex space-x-4">
          <a href="#" aria-label="Facebook" className="hover:text-brand-cta transition-colors">
            <Facebook className="h-6 w-6" />
          </a>
          <a href="#" aria-label="Instagram" className="hover:text-brand-cta transition-colors">
            <Instagram className="h-6 w-6" />
          </a>
          <a href="#" aria-label="Twitter" className="hover:text-brand-cta transition-colors">
            <Twitter className="h-6 w-6" />
          </a>
          <a href="#" aria-label="LinkedIn" className="hover:text-brand-cta transition-colors">
            <Linkedin className="h-6 w-6" />
          </a>
        </div>
      </div>
    </footer>
  )
}
