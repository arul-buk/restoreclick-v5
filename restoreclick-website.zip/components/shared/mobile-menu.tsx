// components/shared/mobile-menu.tsx
// This component provides the mobile navigation menu, which slides in from the right.
// It includes navigation links and is designed to be responsive and accessible.

"use client" // Marks this component as a Client Component due to state and interactivity.

import { useEffect } from "react"
import Link from "next/link" // Next.js Link component for client-side navigation.
import { X } from "lucide-react" // Lucide React icon for closing the menu.
import { Button } from "@/components/ui/button" // Shadcn UI Button component.

// Defines the props for the MobileMenu component.
interface MobileMenuProps {
  isOpen: boolean // Controls the visibility of the menu.
  onClose: () => void // Callback function to close the menu.
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  // useEffect to handle body scroll locking when the menu is open.
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden" // Prevent scrolling on the body.
    } else {
      document.body.style.overflow = "" // Restore body scrolling.
    }
    // Cleanup function: ensure scrolling is re-enabled when component unmounts or isOpen changes.
    return () => {
      document.body.style.overflow = ""
    }
  }, [isOpen]) // Dependency: re-run when isOpen changes.

  return (
    <>
      {/* Overlay: Darkens the background when the menu is open. */}
      {/* z-[998] ensures it's below the menu but above other content. */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-[998] transition-opacity duration-300"
          onClick={onClose} // Close menu when clicking outside.
          aria-hidden="true" // Hide from accessibility tree when closed.
        />
      )}

      {/* Mobile Menu Panel */}
      {/* z-[999] ensures it's on top of the overlay and all other content. */}
      <div
        className={`fixed top-0 right-0 h-full w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-[999]
          ${isOpen ? "translate-x-0" : "translate-x-full"}`} // Slides in/out based on isOpen.
        role="dialog" // ARIA role for dialog.
        aria-modal="true" // Indicates it's a modal dialog.
        aria-label="Mobile navigation menu" // Accessibility label.
      >
        <div className="p-6 flex flex-col h-full">
          {/* Close Button */}
          <div className="flex justify-end mb-8">
            <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close menu">
              <X className="h-6 w-6 text-brand-text" /> {/* Close icon */}
            </Button>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-col space-y-6 text-xl font-semibold text-brand-text flex-grow">
            <Link href="/" onClick={onClose} className="hover:text-brand-cta transition-colors">
              Home
            </Link>
            <Link href="/our-story" onClick={onClose} className="hover:text-brand-cta transition-colors">
              Our Story
            </Link>
            <Link href="/restore-old-photos" onClick={onClose} className="hover:text-brand-cta transition-colors">
              Restore Photos
            </Link>
            <Link href="/blog" onClick={onClose} className="hover:text-brand-cta transition-colors">
              Blog
            </Link>
            <Link href="/contact" onClick={onClose} className="hover:text-brand-cta transition-colors">
              Contact
            </Link>
          </nav>

          {/* Placeholder: Social media links or other footer content for mobile menu */}
          <div className="mt-auto pt-6 border-t border-gray-200 text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} RestoreClick</p>
            {/* Placeholder: Add social media icons here if desired */}
          </div>
        </div>
      </div>
    </>
  )
}
