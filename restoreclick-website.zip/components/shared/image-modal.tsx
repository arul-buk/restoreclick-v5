// components/shared/image-modal.tsx
// This component provides a reusable modal for displaying enlarged images.
// It's useful for showcasing restored photos in a gallery or detailed view.

"use client" // Marks this component as a Client Component due to state and interactivity.

import { AlertDialog, AlertDialogContent, AlertDialogOverlay } from "@/components/ui/alert-dialog" // Shadcn UI Alert Dialog components for modal structure.
import Image from "next/image" // Next.js Image component for optimized images.

// Defines the props for the ImageModal component.
interface ImageModalProps {
  isOpen: boolean // Controls the visibility of the modal.
  onClose: () => void // Callback function to close the modal.
  src: string // URL of the image to display.
  alt: string // Alt text for the image.
}

export default function ImageModal({ isOpen, onClose, src, alt }: ImageModalProps) {
  return (
    // AlertDialog is used as a base for the modal. `open` controls visibility, `onOpenChange` handles closing.
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogOverlay className="bg-black/80 backdrop-blur-sm" /> {/* Dark, blurred overlay */}
      <AlertDialogContent className="max-w-4xl w-[90vw] h-[90vh] p-0 overflow-hidden flex items-center justify-center bg-transparent border-none shadow-none">
        {/* Image displayed within the modal. */}
        <div className="relative w-full h-full">
          <Image
            src={src || "/placeholder.svg"}
            alt={alt}
            fill // Fills the parent container.
            className="object-contain rounded-lg" // Ensures the entire image is visible within the modal, maintains aspect ratio.
          />
        </div>
      </AlertDialogContent>
    </AlertDialog>
  )
}
