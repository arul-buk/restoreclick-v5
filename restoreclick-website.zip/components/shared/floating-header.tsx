// components/shared/floating-header.tsx
// This component defines the main header/navbar for the RestoreClick website.
// It includes the brand logo, main navigation links, and a mobile menu toggle button.
// The header is designed to be always visible (not hiding on scroll).

"use client" // Marks this component as a Client Component due to interactivity.

import Link from "next/link" // Next.js Link component for client-side navigation.
import Image from "next/image" // Next.js Image component for optimized logo.
import { Menu } from "lucide-react" // Lucide React icon for the mobile menu toggle.
import { Button, buttonVariants } from "@/components/ui/button" // Import Button and buttonVariants
import { cn } from "@/lib/utils" // Import cn utility for conditional class names

// Defines the props for the FloatingHeader component.
interface FloatingHeaderProps {
  setIsMobileMenuOpen: (isOpen: boolean) => void // Prop to control mobile menu state
}

export default function FloatingHeader({ setIsMobileMenuOpen }: FloatingHeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-[997] bg-white/90 backdrop-blur-sm shadow-sm transition-all duration-300">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        {/* Brand Logo */}
        <Link href="/" className="flex items-center" aria-label="RestoreClick Home">
          <Image
            src="/placeholder.svg?height=40&width=40&text=Logo" // Placeholder logo image.
            alt="RestoreClick Logo"
            width={40}
            height={40}
            className="mr-3"
          />
          <span className="font-serif text-2xl font-bold text-brand-text">RestoreClick</span>
        </Link>

        {/* Desktop Navigation (hidden on mobile) */}
        <nav className="hidden lg:flex space-x-8">
          <Link href="/" className="text-lg font-medium text-brand-text hover:text-brand-cta transition-colors">
            Home
          </Link>
          <Link
            href="/our-story"
            className="text-lg font-medium text-brand-text hover:text-brand-cta transition-colors"
          >
            Our Story
          </Link>
          <Link
            href="/restore-old-photos"
            className="text-lg font-medium text-brand-text hover:text-brand-cta transition-colors"
          >
            Restore Photos
          </Link>
          <Link href="/blog" className="text-lg font-medium text-brand-text hover:text-brand-cta transition-colors">
            Blog
          </Link>
          <Link href="/contact" className="text-lg font-medium text-brand-text hover:text-brand-cta transition-colors">
            Contact
          </Link>
        </nav>

        {/* CTA Button & Mobile Menu Toggle */}
        <div className="flex items-center space-x-4">
          {/* Preserve Memories CTA Link (visible on sm and up, hidden on lg for nav) */}
          <Link
            href="/restore-old-photos"
            className={cn(
              buttonVariants({ variant: "default" }), // Apply default button styles
              "hidden sm:flex lg:hidden shadow-soft hover:shadow-soft-md",
            )}
          >
            Preserve your Memories
          </Link>
          {/* Preserve Memories CTA Link (visible on lg and up, as part of nav) */}
          <Link
            href="/restore-old-photos"
            className={cn(
              buttonVariants({ variant: "default" }), // Apply default button styles
              "hidden lg:flex shadow-soft hover:shadow-soft-md",
            )}
          >
            Preserve your Memories
          </Link>
          {/* Mobile menu button (visible only on lg and below) */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMobileMenuOpen(true)} // Open menu on click
            className="lg:hidden" // Only show on screens smaller than lg
            aria-label="Open mobile menu"
          >
            <Menu className="h-6 w-6 text-brand-text" /> {/* Menu icon */}
          </Button>
        </div>
      </div>
    </header>
  )
}
