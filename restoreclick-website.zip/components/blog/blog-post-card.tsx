// components/blog/blog-post-card.tsx
// This component renders a single blog post as a card, suitable for listing pages.
// It displays the post's cover image, categories, date, title, and a brief description.

import Image from "next/image" // Next.js Image component for optimized images.
import Link from "next/link" // Next.js Link component for client-side navigation.
import { Card, CardContent } from "@/components/ui/card" // Shadcn UI Card components.
import { Badge } from "@/components/ui/badge" // Shadcn UI Badge component for categories.

// Defines the props for the BlogPostCard component.
interface BlogPostCardProps {
  post: {
    slug: string // Used to create the link to the full blog post.
    title: string
    date: string
    description: string
    coverImage: string // URL for the cover image.
    categories: string[] // Array of categories to display as badges.
  }
}

export default function BlogPostCard({ post }: BlogPostCardProps) {
  return (
    // Wraps the card in a Next.js Link for navigation to the individual blog post page.
    // The 'group' class is used for hover effects on child elements.
    <Link href={`/blog/${post.slug}`} className="block group">
      <Card className="overflow-hidden shadow-soft hover:shadow-soft-md transition-shadow duration-300 h-full flex flex-col">
        {/* Image container with aspect ratio for consistent sizing. */}
        <div className="relative aspect-[3/2] w-full overflow-hidden">
          <Image
            src={post.coverImage || "/placeholder.svg"} // Use placeholder if cover image is missing.
            alt={post.title}
            fill // Fills the parent container.
            className="object-cover group-hover:scale-105 transition-transform duration-300" // Scale on hover effect.
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw" // Image optimization sizes.
          />
        </div>
        {/* Card content area. */}
        <CardContent className="p-8 flex flex-col flex-grow">
          {/* Categories displayed as badges. */}
          <div className="flex flex-wrap gap-2 mb-3">
            {post.categories.map((category) => (
              <Badge
                key={category}
                variant="secondary"
                className="bg-brand-secondary/20 text-brand-secondary text-xs px-2 py-1 rounded-full"
              >
                {category}
              </Badge>
            ))}
          </div>
          {/* Post date. */}
          <p className="text-base text-brand-text/80 mb-2">{post.date}</p>
          {/* Post title, with hover effect. */}
          <h3 className="font-serif text-2xl font-semibold text-brand-text group-hover:text-brand-cta transition-colors mb-3 leading-tight">
            {post.title}
          </h3>
          {/* Post description, allowing it to grow and fill space. */}
          <p className="text-brand-text/80 text-lg leading-relaxed flex-grow">{post.description}</p>
        </CardContent>
      </Card>
    </Link>
  )
}
