// lib/blog-posts.ts
// This file provides mock data and utility functions for blog posts.
// In a real application, this data would typically come from a CMS, database, or markdown files.

// Interface defining the structure of a blog post.
export interface BlogPost {
  id: string
  slug: string // Unique identifier for the URL.
  title: string
  date: string // Format: "Month Day, Year"
  description: string
  coverImage: string // URL for the cover image (currently placeholder).
  author: string
  content: string // Markdown content of the blog post.
  readingTime: number // Estimated reading time in minutes.
  categories: string[] // Array of categories for filtering.
}

// Helper function to calculate approximate reading time.
function calculateReadingTime(text: string): number {
  const wordsPerMinute = 200 // Standard reading speed.
  const wordCount = text.split(/\s+/).length // Count words by splitting on whitespace.
  return Math.ceil(wordCount / wordsPerMinute) // Round up to the nearest minute.
}

// Mock data for several blog posts.
// Placeholder: In a production app, this would be replaced by actual data fetching.
const mockBlogPostsData = [
  {
    id: "1",
    slug: "the-art-of-digital-restoration",
    title: "The Art of Digital Restoration: Bringing Memories Back to Life",
    date: "October 26, 2023",
    description:
      "Discover the meticulous process our digital artisans use to transform faded, damaged photographs into vibrant, lasting heirlooms.",
    coverImage: "/placeholder.svg?width=600&height=400&text=Blog+Post+1", // Placeholder image URL.
    author: "Lily Chen",
    categories: ["Restoration", "Technology"],
    content: `
# The Art of Digital Restoration: Bringing Memories Back to Life

In an age where digital photography dominates, there's a unique charm and irreplaceable value in physical photographs. They are tangible links to our past, holding stories, emotions, and the faces of loved ones. However, time, neglect, and accidents can take their toll, leaving these precious artifacts faded, torn, or discolored. This is where the art of digital photo restoration comes in.

## What is Digital Photo Restoration?

Digital photo restoration is the process of repairing and enhancing old or damaged photographs using digital tools and techniques. It's not just about fixing flaws; it's about breathing new life into an image, bringing it back to its original glory, or even improving upon it.

### The Meticulous Process

Our approach to digital restoration is a blend of advanced technology and human artistry. Each photograph undergoes a meticulous, multi-step process:

1.  **Initial Assessment**: We begin by carefully analyzing the photograph's condition, identifying all damage, from minor dust spots to severe tears, fading, and discoloration. This helps us determine the best restoration strategy.
2.  **Scanning and Digitization**: The physical photograph is high-resolution scanned to create a digital copy. This step is crucial as it captures every detail, allowing for precise work without further damaging the original.
3.  **Damage Repair**: This is often the most time-consuming phase. Our digital artisans use specialized software to:
    *   Remove scratches, dust, and blemishes.
    *   Repair tears, creases, and missing sections.
    *   Reconstruct damaged areas, often by borrowing elements from other parts of the photo or similar images.
4.  **Color Correction and Enhancement**: Faded colors are revived, and color casts are neutralized. We adjust brightness, contrast, and saturation to ensure the image looks natural and vibrant.
5.  **Sharpening and Detail Enhancement**: We carefully enhance details that may have been lost due to blurriness or low resolution, bringing clarity to faces and textures.
6.  **Final Review**: Before delivery, each restored image undergoes a rigorous quality check to ensure it meets our museum-quality standards and exceeds your expectations.

## Why Restore Your Photos?

Restoring your photographs is an investment in your family's legacy. It allows you to:

*   **Preserve History**: Safeguard irreplaceable moments and ensure they can be passed down through generations.
*   **Relive Memories**: See your loved ones and past events as they truly were, with clarity and vibrancy.
*   **Create New Art**: Transform old photos into stunning pieces of art for display in your home.

At RestoreClick, we understand the emotional value embedded in every photograph. Our commitment is to treat your memories with the utmost care and artistry, ensuring they are perfectly preserved for years to come.
`,
  },
  {
    id: "2",
    slug: "preserving-family-legacy",
    title: "Preserving Your Family Legacy: Why Photo Restoration Matters",
    date: "November 10, 2023",
    description:
      "Learn how restoring old photographs is more than just a technical process—it's an act of preserving your unique family history for future generations.",
    coverImage: "/placeholder.svg?width=600&height=400&text=Blog+Post+2",
    author: "David Lee",
    categories: ["Family History", "Legacy"],
    content: `
# Preserving Your Family Legacy: Why Photo Restoration Matters

In a world increasingly focused on the future, it's easy to overlook the treasures of the past. Yet, within the faded hues and creased edges of old photographs lies a profound connection to our heritage. These images are more than just paper and ink; they are tangible links to our ancestors, our childhoods, and the stories that shaped us. This is why photo restoration isn't just a service—it's an act of preserving your family's legacy.

## The Silent Storytellers

Every photograph tells a story. A sepia-toned portrait might whisper tales of resilience from a bygone era. A vibrant snapshot from a family vacation captures the laughter and joy of a specific moment. When these images degrade, their stories begin to fade with them. Fading colors, tears, scratches, and water damage don't just obscure faces; they threaten to erase the narratives, the emotions, and the very essence of those captured moments.

## More Than Just an Image

Restoring a photograph goes beyond mere technical repair. It's about:

*   **Reconnecting with Roots**: Seeing a clear, vibrant image of a great-grandparent can forge a powerful connection to your family's history, helping you understand where you come from.
*   **Sharing with Future Generations**: A restored photo can be shared, printed, and displayed, becoming a focal point for storytelling and a source of pride for children and grandchildren. It transforms a fragile relic into a durable heirloom.
*   **Healing and Remembrance**: For many, old photos are a way to remember loved ones who are no longer with us. A beautifully restored image can bring comfort and a sense of their continued presence.
*   **Unlocking Hidden Details**: Restoration can reveal details previously obscured by damage or age—a subtle expression, a forgotten background element, or the true colors of a cherished outfit.

## The Digital Advantage

Digital restoration offers a unique advantage: it preserves the original while creating a perfect, durable copy. Your physical photograph remains untouched, while a high-resolution digital version is created, free from the ravages of time. This digital heirloom can be backed up, shared instantly, and printed countless times without fear of further degradation.

At RestoreClick, we believe that every family's history is a masterpiece worth preserving. By entrusting us with your memories, you're not just restoring photos; you're safeguarding your legacy, ensuring that the stories of your past continue to inspire and connect future generations.
`,
  },
  {
    id: "3",
    slug: "choosing-the-right-service",
    title: "Choosing the Right Restoration Service: What to Look For",
    date: "November 25, 2023",
    description:
      "Navigate the world of photo restoration with confidence. We share key factors to consider when entrusting your precious memories to a service.",
    coverImage: "/placeholder.svg?width=600&height=400&text=Blog+Post+3",
    author: "Sarah Miller",
    categories: ["Tips", "Service"],
    content: `
# Choosing the Right Restoration Service: What to Look For

Entrusting your precious, often irreplaceable, photographs to a restoration service can feel daunting. How do you know you're choosing the right one? With so many options available, it's crucial to understand what distinguishes a truly professional and reliable service from the rest. Here’s a guide to help you make an informed decision.

## 1. Expertise and Experience

Look for a service that demonstrates clear expertise in photo restoration. This isn't just about using software; it's about understanding photographic history, materials, and the nuances of light and shadow.

*   **Portfolio**: A strong portfolio showcasing a variety of before-and-after examples is essential. Look for diverse types of damage (tears, fading, water damage, mold) and different photographic eras.
*   **Artisan Skill**: Does the service emphasize the role of human artisans alongside technology? The best results come from a blend of advanced AI tools and the discerning eye of a skilled professional.

## 2. Transparency in Process

A reputable service will be transparent about how they handle your photos and what their process entails.

*   **Detailed Steps**: They should clearly outline their restoration steps, from initial assessment to final delivery.
*   **Communication**: Will you be kept informed throughout the process? Are they accessible for questions?
*   **Pricing**: Is the pricing clear and upfront, or are there hidden fees? Understand what's included in the cost.

## 3. Quality of Output

Ultimately, the quality of the restored image is paramount.

*   **High Resolution**: Ensure you receive high-resolution digital files suitable for printing and archiving.
*   **Natural Appearance**: The goal of restoration is to make the photo look natural, not overly processed or artificial. Colors should be accurate, and details should be sharp without looking pixelated.
*   **Satisfaction Guarantee**: A confident service will offer a satisfaction guarantee, ensuring you are happy with the final result.

## 4. Security and Care for Originals

If you're sending physical photos, their safe handling is critical.

*   **Secure Handling**: Inquire about their procedures for receiving, storing, and returning your original photographs.
*   **Digital Copies**: Confirm that they create high-quality digital scans and that your originals are not altered in any way.

## 5. Customer Reviews and Testimonials

What do other customers say? Look for independent reviews and testimonials that speak to the service's reliability, quality, and customer care.

Choosing RestoreClick means choosing a partner dedicated to preserving your most cherished memories with the highest level of care and artistry. We pride ourselves on our transparent process, expert artisans, and commitment to delivering museum-quality results that you and your family will treasure for generations.
`,
  },
  {
    id: "4",
    slug: "beyond-the-frame",
    title: "Beyond the Frame: Creative Ways to Display Restored Photos",
    date: "December 5, 2023",
    description:
      "Once restored, your photos deserve to be seen! Explore inspiring ideas for showcasing your digital heirlooms as art in your home.",
    coverImage: "/placeholder.svg?width=600&height=400&text=Blog+Post+4",
    author: "Alex Johnson",
    categories: ["Display", "Home Decor"],
    content: `
# Beyond the Frame: Creative Ways to Display Restored Photos

You've taken the wonderful step of restoring your precious family photographs, transforming faded memories into vibrant digital heirlooms. Now what? These aren't just files to be stored on a hard drive; they are works of art, rich with history and emotion, deserving of a place of honor in your home. Here are some creative ways to display your restored photos, bringing your family's legacy to life.

## 1. The Gallery Wall: A Curated Family History

Transform a blank wall into a captivating narrative of your family's journey. Mix and match restored vintage photos with contemporary family portraits.

*   **Vary Frame Styles**: Use a mix of classic wooden frames, sleek metallics, and even frameless acrylic prints for visual interest.
*   **Themed Groupings**: Dedicate sections to specific eras, family branches, or events (e.g., "Wedding Memories," "Childhood Summers").
*   **Digital Displays**: Integrate a high-resolution digital photo frame into your gallery wall to showcase a rotating selection of restored images.

## 2. Bespoke Photo Albums and Books

For a tactile and intimate experience, create custom-designed photo albums or coffee-table books.

*   **Heirloom Quality**: Choose archival-quality paper and binding for a book that will last for generations.
*   **Narrative Flow**: Arrange photos chronologically or thematically, adding captions and anecdotes to tell a richer story.
*   **Gift Ideas**: A beautifully printed album of restored photos makes an incredibly thoughtful and personal gift for family members.

## 3. Large-Format Art Prints

Turn a single, particularly striking restored photograph into a statement piece.

*   **Canvas Prints**: Give your photo the look and feel of a painting.
*   **Metal Prints**: For a modern, vibrant display with incredible detail and luminosity.
*   **Acrylic Prints**: Offer a sleek, contemporary look with depth and brilliance.

## 4. Digital Integration: Smart Homes and Screensavers

Leverage modern technology to keep your memories present in your daily life.

*   **Smart Displays**: Set your restored photos as rotating backgrounds on smart home devices like Google Nest Hub or Amazon Echo Show.
*   **Computer Screensavers**: Enjoy a personal slideshow of your family history every time your computer is idle.
*   **Digital Photo Frames**: Invest in a high-quality digital frame that can display a continuous loop of your restored collection.

## 5. Unique Home Decor Accents

Think beyond traditional frames and explore creative ways to incorporate photos into your decor.

*   **Photo Coasters or Mugs**: A subtle way to integrate memories into everyday items.
*   **Custom Textiles**: Print a favorite restored image onto a throw pillow or blanket.
*   **Shadow Boxes**: Combine a restored photo with small family heirlooms or mementos for a three-dimensional display.

Your restored photographs are a testament to your family's enduring story. By thoughtfully displaying them, you not only honor the past but also enrich your present and inspire future generations.
`,
  },
  {
    id: "5",
    slug: "the-future-of-memory",
    title: "The Future of Memory: AI's Role in Photo Preservation",
    date: "December 18, 2023",
    description:
      "Delve into how cutting-edge AI technology is revolutionizing photo restoration, making it more precise and accessible than ever before.",
    coverImage: "/placeholder.svg?width=600&height=400&text=Blog+Post+5",
    author: "Dr. Evelyn Reed",
    categories: ["Technology", "Future"],
    content: `
# The Future of Memory: AI's Role in Photo Preservation

For decades, photo restoration was a painstaking, manual process, requiring immense skill and time from trained artists. While human artistry remains invaluable, the advent of Artificial Intelligence (AI) is revolutionizing the field, making high-quality photo preservation more accessible, efficient, and precise than ever before.

## AI as a Digital Artisan's Assistant

At RestoreClick, we view AI not as a replacement for human expertise, but as a powerful assistant to our digital artisans. AI algorithms can perform repetitive and complex tasks with incredible speed and accuracy, freeing up our experts to focus on the nuanced, artistic decisions that truly bring a photo back to life.

### How AI is Transforming Restoration:

1.  **Automated Damage Detection**: AI can quickly scan an image and identify various types of damage—scratches, dust, tears, and even areas of severe fading—with a precision that would take a human eye much longer to achieve.
2.  **Intelligent Inpainting and Reconstruction**: For missing or severely damaged areas, advanced AI models can "inpain" or intelligently fill in gaps by analyzing surrounding pixels and predicting what the missing content should look like. This is particularly powerful for reconstructing faces or intricate patterns.
3.  **Realistic Colorization**: Black and white photos can be colorized with remarkable realism. AI models trained on vast datasets of images can infer natural colors for skin tones, landscapes, and objects, adding a new dimension to historical photographs.
4.  **Enhanced Detail and Sharpening**: AI-powered super-resolution techniques can upscale low-resolution images and enhance fine details without introducing artifacts, making old, blurry photos surprisingly clear.
5.  **Fading and Discoloration Correction**: AI can analyze color shifts caused by age and light exposure, then intelligently correct them to restore the original vibrancy and tone of the photograph.

## The Ethical Considerations

While AI offers incredible potential, it also raises important ethical questions. At RestoreClick, we are committed to using AI responsibly:

*   **Preserving Authenticity**: Our goal is to restore, not to alter history. AI is used to bring back what was lost, not to invent new elements or distort the original intent of the photograph.
*   **Human Oversight**: Every AI-enhanced restoration undergoes rigorous human review by our skilled artisans. This ensures artistic integrity and addresses any subtle imperfections that AI might miss.
*   **Transparency**: We believe in being transparent about our use of AI, educating our clients on how technology assists in achieving superior results.

The future of memory preservation is bright, with AI playing an increasingly vital role. By combining cutting-edge artificial intelligence with the irreplaceable touch of human artistry, RestoreClick is dedicated to ensuring that your family's most cherished moments are preserved with unparalleled quality and care for generations to come.
`,
  },
]

// Function to get all blog posts.
// Placeholder: Simulates network delay. In a real app, this would fetch from a backend.
export async function getBlogPosts(): Promise<BlogPost[]> {
  await new Promise((resolve) => setTimeout(resolve, 100)) // Simulate network delay.
  return mockBlogPostsData.map((post) => ({
    ...post,
    readingTime: calculateReadingTime(post.content), // Calculate reading time for each post.
  }))
}

// Function to get a single blog post by its slug.
// Placeholder: Simulates network delay and finds post from mock data.
export async function getBlogPostBySlug(slug: string): Promise<BlogPost | null> {
  await new Promise((resolve) => setTimeout(resolve, 100)) // Simulate network delay.
  const post = mockBlogPostsData.find((p) => p.slug === slug) // Find the post by slug.
  if (!post) return null // Return null if not found.
  return {
    ...post,
    readingTime: calculateReadingTime(post.content), // Calculate reading time.
  }
}

// Function to get all unique blog categories.
// Placeholder: Extracts categories from mock data.
export async function getUniqueBlogCategories(): Promise<string[]> {
  const posts = await getBlogPosts() // Get all posts.
  const categories = new Set<string>() // Use a Set to store unique categories.
  posts.forEach((post) => {
    post.categories.forEach((category) => categories.add(category)) // Add all categories from posts.
  })
  return Array.from(categories).sort() // Convert Set to Array and sort alphabetically.
}
