// tailwind.config.ts
// This file configures Tailwind CSS for the project.
// It extends the default Tailwind configuration with custom colors, fonts, and shadows
// to match the "RestoreClick" brand identity.

import type { Config } from "tailwindcss"

const config = {
  // Specifies the files Tailwind should scan for utility classes.
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  prefix: "", // No prefix for Tailwind classes.
  theme: {
    // Custom container settings for responsive layouts.
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      // Custom color palette for the "RestoreClick" brand.
      // These colors are derived from the prompt's requirements:
      // Primary: light grey or off-white (#F9F9F7) for background.
      // Text: charcoal grey (#333333).
      // Accent: deep, rich emerald green (#0D5C46) or midnight blue (#003366).
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        brand: {
          background: "#F9F9F7", // Light grey/off-white for main backgrounds
          text: "#333333", // Charcoal grey for primary text
          cta: "#0D5C46", // Emerald green for Call-to-Action buttons and highlights
          secondary: "#003366", // Midnight blue for secondary accents (e.g., dividers)
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      // Custom border-radius values.
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      // Custom font families.
      // 'serif' is mapped to Playfair Display or Cormorant Garamond (via globals.css).
      // 'sans' is mapped to Inter or Montserrat (via globals.css).
      fontFamily: {
        serif: ["var(--font-serif)", "serif"],
        sans: ["var(--font-sans)", "sans-serif"],
      },
      // Keyframe animations for subtle effects.
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      // Animation utilities.
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
      // Custom box shadows for a "soft" or "premium" feel.
      boxShadow: {
        soft: "0 4px 12px rgba(0, 0, 0, 0.08)",
        "soft-md": "0 6px 18px rgba(0, 0, 0, 0.12)",
        "soft-lg": "0 10px 30px rgba(0, 0, 0, 0.15)",
      },
    },
  },
  // Plugins for additional Tailwind features (e.g., typography for prose).
  plugins: [require("tailwindcss-animate"), require("@tailwindcss/typography")],
} satisfies Config

export default config
