import { buttonVariants } from "@/components/ui/button" // Import buttonVariants
import { cn } from "@/lib/utils" // Import cn utility
import { CheckCircle2, PackageCheck, ShoppingCart, Trophy } from "lucide-react"
import Link from "next/link"

export default function PaymentSuccessPage() {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md text-center">
        <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h1 className="text-2xl font-semibold text-gray-800 mb-2">Payment Successful!</h1>
        <p className="text-gray-600 mb-4">Thank you for your order. Your payment has been processed successfully.</p>
        <div className="flex items-center justify-center space-x-4 mb-4">
          <PackageCheck className="w-6 h-6 text-blue-500" />
          <span className="text-sm text-gray-500">Order Confirmed</span>
          <ShoppingCart className="w-6 h-6 text-blue-500" />
          <span className="text-sm text-gray-500">Payment Received</span>
          <Trophy className="w-6 h-6 text-blue-500" />
          <span className="text-sm text-gray-500">Preparing for Shipment</span>
        </div>
        <Link
          href="/"
          className={cn(
            buttonVariants({ variant: "default" }), // Apply default button styles
          )}
        >
          Return to Homepage
        </Link>
      </div>
    </div>
  )
}
