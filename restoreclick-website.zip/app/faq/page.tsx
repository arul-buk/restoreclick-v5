// app/faq/page.tsx
// This page serves as the entry point for the Frequently Asked Questions (FAQ) section.
// It's a Server Component that sets metadata and renders the client-side FAQ logic.

import type { Metadata } from "next"
import FaqPageClient from "./FaqPageClient" // Client component for interactive FAQ.

// Metadata for the FAQ page, used for SEO and browser tab title.
export const metadata: Metadata = {
  title: "FAQ | RestoreClick",
  description: "Find answers to frequently asked questions about RestoreClick's photo restoration service.",
}

// FAQPage component renders the client-side FAQ section.
export default function FAQPage() {
  return <FaqPageClient /> // Renders the client component.
}
