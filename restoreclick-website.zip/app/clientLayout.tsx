// app/clientLayout.tsx
// This is a client-side layout component that wraps the main content of the application.
// It provides global client-side features like the floating header, mobile menu,
// and smooth scroll navigation, ensuring they are present across all pages.

"use client" // Marks this component as a Client Component.

import type React from "react"

import { useState } from "react"
import FloatingHeader from "@/components/shared/floating-header" // Global header component.
import MobileMenu from "@/components/shared/mobile-menu" // Mobile navigation menu component.
import SmoothScrollNav from "@/components/shared/smooth-scroll-nav" // Floating scroll dots.
import Footer from "@/components/shared/footer" // Global footer component.

// Defines the props for the ClientLayout component.
interface ClientLayoutProps {
  children: React.ReactNode // Represents the content of the current page.
}

export default function ClientLayout({ children }: ClientLayoutProps) {
  // State to control the open/close status of the mobile menu.
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <>
      {/* Floating Header: Always visible at the top, includes the mobile menu toggle. */}
      <FloatingHeader onMobileMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)} />

      {/* Mobile Menu: Conditionally rendered based on `isMobileMenuOpen` state.
          It receives the state and a function to close itself. */}
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />

      {/* Main content of the page. */}
      {children}

      {/* Smooth Scroll Navigation: Floating dots for desktop, scroll indicator for mobile. */}
      <SmoothScrollNav />

      {/* Global Footer: Appears at the bottom of every page. */}
      <Footer />
    </>
  )
}
