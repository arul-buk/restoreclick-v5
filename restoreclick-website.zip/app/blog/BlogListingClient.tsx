"use client" // This page needs to be a client component for state management

import { useState, useEffect } from "react"
import { getBlogPosts, getUniqueBlogCategories, type BlogPost } from "@/lib/blog-posts"
import BlogPostCard from "@/components/blog/blog-post-card"
import { Button } from "@/components/ui/button" // Assuming Button component is available

export default function BlogListingClient() {
  const [allBlogPosts, setAllBlogPosts] = useState<BlogPost[]>([])
  const [filteredBlogPosts, setFilteredBlogPosts] = useState<BlogPost[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("All")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      const posts = await getBlogPosts()
      const uniqueCategories = await getUniqueBlogCategories()
      setAllBlogPosts(posts)
      setFilteredBlogPosts(posts) // Initially show all posts
      setCategories(["All", ...uniqueCategories])
      setIsLoading(false)
    }
    fetchData()
  }, [])

  useEffect(() => {
    if (selectedCategory === "All") {
      setFilteredBlogPosts(allBlogPosts)
    } else {
      setFilteredBlogPosts(allBlogPosts.filter((post) => post.categories.includes(selectedCategory)))
    }
  }, [selectedCategory, allBlogPosts])

  return (
    <div className="bg-brand-background text-brand-text min-h-screen py-16 pt-28">
      <div className="container mx-auto px-6 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="font-serif text-5xl lg:text-6xl font-normal text-brand-text mb-4">
            From the RestoreClick Blog
          </h1>
          <div className="w-32 h-px bg-brand-secondary mx-auto mb-6"></div>
          <p className="text-2xl text-brand-text/80 max-w-2xl mx-auto leading-relaxed">
            Insights, stories, and tips on preserving your cherished memories and family history.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 text-lg rounded-full ${
                selectedCategory === category
                  ? "bg-brand-cta text-white hover:bg-brand-cta/90"
                  : "border-brand-text/20 text-brand-text/80 hover:bg-brand-background hover:border-brand-cta hover:text-brand-cta"
              }`}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Blog Post Grid */}
        {isLoading ? (
          <div className="text-center text-xl text-brand-text/70">Loading blog posts...</div>
        ) : filteredBlogPosts.length === 0 ? (
          <div className="text-center text-xl text-brand-text/70">No posts found for this category.</div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredBlogPosts.map((post) => (
              <BlogPostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
