// app/blog/[slug]/page.tsx
// This page renders an individual blog post based on its slug.
// It's a Server Component that fetches blog post data and generates static paths for SSG.

import type { Metadata } from "next"
import Image from "next/image" // Next.js Image component for optimized images.
import { getBlogPostBySlug, getBlogPosts } from "@/lib/blog-posts" // Utility functions to fetch blog data.
import { notFound } from "next/navigation" // Next.js utility to render a 404 page.

// generateStaticParams is a Next.js function for Static Site Generation (SSG).
// It tells Next.js which slugs (paths) to pre-render at build time.
export async function generateStaticParams() {
  const posts = await getBlogPosts() // Fetches all blog posts.
  return posts.map((post) => ({
    slug: post.slug, // Returns an array of objects with 'slug' for each post.
  }))
}

// generateMetadata is a Next.js function to dynamically generate metadata (SEO) for each page.
// It's an async function that fetches the specific post's data to populate title, description, etc.
export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = await getBlogPostBySlug(params.slug) // Fetch the specific blog post.

  // If the post is not found, return a generic "Not Found" metadata.
  if (!post) {
    return {
      title: "Post Not Found | RestoreClick Blog",
    }
  }

  // Return specific metadata for the found blog post.
  return {
    title: `${post.title} | RestoreClick Blog`,
    description: post.description,
    openGraph: {
      images: [post.coverImage], // Open Graph image for social media sharing.
    },
  }
}

// BlogPostPage component renders the content of a single blog post.
// It's an async Server Component, allowing direct data fetching.
export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await getBlogPostBySlug(params.slug) // Fetch the blog post data using the slug from params.

  // If no post is found for the given slug, render the Next.js 404 page.
  if (!post) {
    notFound()
  }

  return (
    // Main container for the blog post, applying brand background and text colors.
    <div className="bg-brand-background text-brand-text min-h-screen py-16 pt-28">
      {" "}
      {/* pt-28 for header spacing */}
      <div className="container mx-auto px-6 max-w-4xl">
        {/* Post Header Section */}
        <header className="text-center mb-12">
          <h1 className="font-serif text-4xl lg:text-5xl font-bold text-brand-text mb-4 leading-tight">{post.title}</h1>
          <p className="text-lg text-brand-text/70 mb-2">
            By {post.author} &bull; {post.date} &bull; {post.readingTime} min read
          </p>
          {/* Decorative divider */}
          <div className="w-24 h-px bg-brand-secondary mx-auto mt-6"></div>
        </header>

        {/* Cover Image Section */}
        <div className="relative aspect-[16/9] w-full mb-12 rounded-lg overflow-hidden shadow-soft">
          <Image
            src={post.coverImage || "/placeholder.svg"} // Use placeholder if cover image is missing.
            alt={post.title}
            fill // Fills the parent container.
            className="object-cover" // Ensures image covers the area.
            priority // Prioritize loading for LCP.
          />
        </div>

        {/* Main Content Area */}
        <main className="grid lg:grid-cols-12 gap-12">
          {/* Table of Contents (Placeholder) */}
          <aside className="lg:col-span-3 hidden lg:block">
            <div className="sticky top-32 space-y-4">
              <h3 className="font-serif text-xl font-semibold text-brand-text">Table of Contents</h3>
              <nav className="space-y-2 text-sm text-brand-text/70">
                {/*
                  Placeholder Handoff: Dynamic Table of Contents
                  Implementing a dynamic, sticky TOC with active highlighting
                  requires client-side JavaScript to parse headings from the rendered MDX
                  and track scroll position. This is complex in Next.js without
                  a full MDX compilation pipeline.
                  For a full implementation, you would typically:
                  1. Parse MDX to extract headings (h2, h3) with IDs.
                  2. Render these headings as a list of links here.
                  3. Use Intersection Observer API or scroll events to highlight
                     the active link based on the user's scroll position.
                */}
                <p className="italic">(Dynamic Table of Contents would appear here for longer articles)</p>
                {/* Example static links for demonstration purposes */}
                <ul className="space-y-1">
                  <li>
                    <a href="#what-is-digital-photo-restoration" className="hover:text-brand-cta">
                      What is Digital Photo Restoration?
                    </a>
                  </li>
                  <li>
                    <a href="#the-meticulous-process" className="hover:text-brand-cta">
                      The Meticulous Process
                    </a>
                  </li>
                  <li>
                    <a href="#why-restore-your-photos" className="hover:text-brand-cta">
                      Why Restore Your Photos?
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </aside>

          {/* Article Content */}
          {/* The 'prose' class from @tailwindcss/typography plugin styles the raw HTML content. */}
          <article
            className="lg:col-span-9 prose prose-lg lg:prose-xl mx-auto text-brand-text prose-headings:font-serif prose-headings:text-brand-text prose-a:text-brand-cta prose-a:hover:text-brand-cta/80 prose-strong:text-brand-text"
            dangerouslySetInnerHTML={{ __html: post.content }} // Renders HTML content directly.
          />
        </main>
      </div>
    </div>
  )
}
