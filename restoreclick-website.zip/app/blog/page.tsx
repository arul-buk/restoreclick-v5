// app/blog/page.tsx
// This is the main page for the blog listing.
// It's a Server Component that defines metadata and renders the client-side blog listing component.

import type { Metadata } from "next" // Metadata is imported for SEO purposes.
import BlogListingClient from "./BlogListingClient" // Client component that handles blog post fetching and filtering.

// Metadata for the blog listing page, used for SEO and browser tab title.
// Although BlogListingClient is a client component, metadata can still be defined
// in its parent Server Component (this file) for optimal SEO.
export const metadata: Metadata = {
  title: "Blog | RestoreClick",
  description:
    "Explore articles and insights from the RestoreClick blog on photo restoration, family legacy, and more.",
}

// BlogListingPage component renders the client-side blog listing.
export default function BlogListingPage() {
  return <BlogListingClient /> // Renders the client component.
}
