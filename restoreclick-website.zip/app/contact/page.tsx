// app/contact/page.tsx
// This page serves as the entry point for the contact form.
// It's a Server Component that sets metadata and renders the client-side contact form logic.

import type { Metadata } from "next"
import ContactPageClient from "./ContactPageClient" // Client component for interactive contact form.

// Metadata for the contact page, used for SEO and browser tab title.
export const metadata: Metadata = {
  title: "Contact Us | RestoreClick",
  description: "Get in touch with RestoreClick for inquiries about photo restoration services.",
}

// ContactPage component renders the main structure of the contact page.
export default function ContactPage() {
  return <ContactPageClient /> // Renders the client component.
}
