// app/contact/ContactPageClient.tsx
// This client component provides the interactive contact form for RestoreClick.
// It handles form state, submission, and displays success/error messages.

"use client" // Marks this component as a Client Component due to state and form handling.

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button" // Shadcn UI Button component.
import { Input } from "@/components/ui/input" // Shadcn UI Input component.
import { Textarea } from "@/components/ui/textarea" // Shadcn UI Textarea component.
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert" // Shadcn UI Alert components for messages.
import { Mail, Phone, MapPin, CheckCircle, XCircle } from "lucide-react" // Lucide React icons.

export default function ContactPageClient() {
  // State for form fields.
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  // State for loading status during form submission.
  const [isLoading, setIsLoading] = useState(false)
  // State for success message.
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  // State for error message.
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  // Handles changes to form input fields.
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }))
  }

  // Handles form submission.
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault() // Prevent default form submission behavior.
    setIsLoading(true) // Set loading state.
    setSuccessMessage(null) // Clear previous messages.
    setErrorMessage(null)

    // Basic form validation.
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      setErrorMessage("Please fill in all fields.")
      setIsLoading(false)
      return
    }
    if (!formData.email.includes("@") || !formData.email.includes(".")) {
      setErrorMessage("Please enter a valid email address.")
      setIsLoading(false)
      return
    }

    // Placeholder Handoff: Form Submission
    // In a real application, this would send data to a backend API or a server action
    // (e.g., using fetch or a Next.js Server Action) to handle email sending.
    // For now, it simulates a delay and logs to the console.
    console.log("Simulating form submission:", formData)
    await new Promise((resolve) => setTimeout(resolve, 1500)) // Simulate network request delay.

    // Simulate success or failure.
    const isSuccess = Math.random() > 0.2 // 80% chance of success for demo.

    if (isSuccess) {
      setSuccessMessage("Your message has been sent successfully! We will get back to you shortly.")
      setFormData({ name: "", email: "", subject: "", message: "" }) // Clear form on success.
    } else {
      setErrorMessage("Failed to send your message. Please try again later.")
    }

    setIsLoading(false) // Reset loading state.
  }

  return (
    <div className="bg-brand-background text-brand-text min-h-screen py-16 pt-28">
      {" "}
      {/* pt-28 for header spacing */}
      <div className="container mx-auto px-6 max-w-6xl">
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="font-serif text-4xl lg:text-5xl font-normal text-brand-text mb-4">Get in Touch</h1>
          <div className="w-32 h-px bg-brand-secondary mx-auto mb-6"></div>
          <p className="text-xl text-brand-text/80 max-w-2xl mx-auto leading-relaxed">
            Have questions about our services or a specific restoration project? We're here to help.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Information Section */}
          <div className="bg-white p-8 rounded-lg shadow-soft">
            <h2 className="font-serif text-3xl font-semibold text-brand-text mb-6">Contact Information</h2>
            <div className="space-y-6 text-lg text-brand-text/90">
              <div className="flex items-center">
                <Mail className="h-6 w-6 text-brand-cta mr-4" />
                <span>info@restoreclick.com</span>
              </div>
              <div className="flex items-center">
                <Phone className="h-6 w-6 text-brand-cta mr-4" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-start">
                <MapPin className="h-6 w-6 text-brand-cta mr-4 flex-shrink-0" />
                <span>
                  RestoreClick Headquarters
                  <br />
                  123 Memory Lane
                  <br />
                  Heritage City, HC 90210
                  <br />
                  United States
                </span>
              </div>
            </div>
            {/* Placeholder: Social media links could be added here */}
            <div className="mt-8">
              <h3 className="font-serif text-2xl font-semibold text-brand-text mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                {/* Placeholder: Replace with actual social media links */}
                <a href="#" aria-label="Facebook" className="text-brand-text/70 hover:text-brand-cta transition-colors">
                  <Mail className="h-7 w-7" /> {/* Using Mail icon as a placeholder for social icons */}
                </a>
                <a
                  href="#"
                  aria-label="Instagram"
                  className="text-brand-text/70 hover:text-brand-cta transition-colors"
                >
                  <Mail className="h-7 w-7" />
                </a>
                <a href="#" aria-label="Twitter" className="text-brand-text/70 hover:text-brand-cta transition-colors">
                  <Mail className="h-7 w-7" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form Section */}
          <div className="bg-white p-8 rounded-lg shadow-soft">
            <h2 className="font-serif text-3xl font-semibold text-brand-text mb-6">Send Us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-lg font-medium text-brand-text mb-2">
                  Your Name
                </label>
                <Input
                  type="text"
                  id="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                  disabled={isLoading}
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-lg font-medium text-brand-text mb-2">
                  Your Email
                </label>
                <Input
                  type="email"
                  id="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                  disabled={isLoading}
                />
              </div>
              <div>
                <label htmlFor="subject" className="block text-lg font-medium text-brand-text mb-2">
                  Subject
                </label>
                <Input
                  type="text"
                  id="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                  disabled={isLoading}
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-lg font-medium text-brand-text mb-2">
                  Your Message
                </label>
                <Textarea
                  id="message"
                  rows={5}
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                  disabled={isLoading}
                />
              </div>
              {/* Display success or error messages */}
              {successMessage && (
                <Alert className="bg-green-50 border-green-200 text-green-700">
                  <CheckCircle className="h-5 w-5" />
                  <AlertTitle>Success!</AlertTitle>
                  <AlertDescription>{successMessage}</AlertDescription>
                </Alert>
              )}
              {errorMessage && (
                <Alert variant="destructive">
                  <XCircle className="h-5 w-5" />
                  <AlertTitle>Error!</AlertTitle>
                  <AlertDescription>{errorMessage}</AlertDescription>
                </Alert>
              )}
              <Button
                type="submit"
                className="w-full bg-brand-cta hover:bg-brand-cta/90 text-white font-semibold py-6 text-lg"
                disabled={isLoading} // Disable button when loading.
              >
                {isLoading ? "Sending Message..." : "Send Message"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
