// app/restore-old-photos/page.tsx
// This page serves as the entry point for users to upload photos for restoration.
// It's a Server Component that sets metadata and renders the client-side logic.

import type { Metadata } from "next"
import RestorePhotosClient from "./restore-photos-client" // Client component for interactive upload logic.

// Metadata for the page, used for SEO and browser tab title.
export const metadata: Metadata = {
  title: "Restore Your Photos | RestoreClick",
  description: "Upload your precious photographs and let our digital artisans restore them to their former glory.",
}

// RestorePhotosPage component renders the main structure of the photo upload page.
export default function RestorePhotosPage() {
  return (
    // Main container for the page, applying brand background and ensuring minimum height.
    <div className="bg-brand-background min-h-screen pt-20">
      {" "}
      {/* pt-20 for header spacing */}
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Page Header Section */}
          <div className="text-center mb-12">
            <h1 className="font-serif text-4xl lg:text-5xl font-normal text-brand-text mb-4">
              Restore Your Precious Memories
            </h1>
            {/* Decorative divider */}
            <div className="w-32 h-px bg-brand-secondary mx-auto mb-6"></div>
            <p className="text-xl text-brand-text/80 max-w-2xl mx-auto leading-relaxed">
              Upload your photographs and let our digital artisans bring them back to life. Each image will be carefully
              restored with museum-quality precision.
            </p>
          </div>

          {/* Client-side component handling the actual photo upload and processing logic. */}
          <RestorePhotosClient />
        </div>
      </div>
    </div>
  )
}
