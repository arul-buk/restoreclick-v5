"use client"
import { useState, useCallback, useRef } from "react"
import type React from "react"

import { useRouter } from "next/navigation" // Import useRouter
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { UploadCloud, ImageIcon, CheckCircle, XCircle, Loader2 } from "lucide-react" // Import Plus icon
import Image from "next/image"

interface UploadedFile {
  id: string
  name: string
  size: number
  status: "pending" | "uploading" | "completed" | "failed"
  progress: number // 0-100
  previewUrl: string // URL for image preview
}

export default function RestorePhotosClient() {
  const router = useRouter() // Initialize useRouter

  const [files, setFiles] = useState<UploadedFile[]>([])
  const [uploadMessage, setUploadMessage] = useState<string | null>(null)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = event.target.files
    if (selectedFiles) {
      processFiles(Array.from(selectedFiles))
    }
  }

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault() // Prevent default browser handling of dropped files.
    event.stopPropagation() // Stop event propagation.
    const droppedFiles = event.dataTransfer.files
    if (droppedFiles) {
      processFiles(Array.from(droppedFiles))
    }
  }, [])

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    event.stopPropagation()
  }, [])

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  const processFiles = (newFiles: File[]) => {
    setUploadMessage(null) // Clear previous messages.
    setUploadError(null)

    const filesToAdd: UploadedFile[] = newFiles.map((file) => ({
      id: Math.random().toString(36).substring(2, 9), // Simple unique ID.
      name: file.name,
      size: file.size,
      status: "pending",
      progress: 0,
      previewUrl: URL.createObjectURL(file), // Create a temporary URL for image preview.
    }))

    setFiles((prevFiles) => [...prevFiles, ...filesToAdd]) // Add new files to the list.

    // Simulate upload for each new file.
    filesToAdd.forEach((file) => simulateUpload(file.id))
  }

  const simulateUpload = (fileId: string) => {
    let progress = 0
    const interval = setInterval(() => {
      progress += 10
      if (progress <= 100) {
        setFiles((prevFiles) => prevFiles.map((f) => (f.id === fileId ? { ...f, status: "uploading", progress } : f)))
      } else {
        clearInterval(interval)
        setFiles((prevFiles) =>
          prevFiles.map((f) => (f.id === fileId ? { ...f, status: "completed", progress: 100 } : f)),
        )
        checkAllUploadsComplete() // Check if all uploads are done.
      }
    }, 150) // Update progress every 150ms.
  }

  const checkAllUploadsComplete = () => {
    // Use a timeout to ensure state updates from simulateUpload have propagated.
    setTimeout(() => {
      const allCompleted = files.every((f) => f.status === "completed")
      if (allCompleted && files.length > 0) {
        setUploadMessage("All photos uploaded successfully! Ready to proceed.")
      }
    }, 200)
  }

  const handleProceedToPayment = () => {
    const allCompleted = files.every((f) => f.status === "completed")
    if (files.length === 0) {
      setUploadError("Please upload at least one photo to proceed.")
      return
    }
    if (!allCompleted) {
      setUploadError("Please wait for all photos to finish uploading before proceeding.")
      return
    }
    setUploadError(null)
    router.push("/payment") // Navigate to the mock payment page.
  }

  return (
    <div className="bg-white p-8 rounded-lg shadow-soft">
      {/* Drag & Drop Area */}
      <div
        className="border-2 border-dashed border-brand-text/20 rounded-lg p-12 text-center cursor-pointer hover:border-brand-cta transition-colors mb-8"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={triggerFileInput}
      >
        <UploadCloud className="h-16 w-16 text-brand-cta mx-auto mb-4" />
        <p className="text-xl font-semibold text-brand-text mb-2">Drag & Drop Your Photos Here</p>
        <p className="text-brand-text/70 mb-4">or click to browse files</p>
        <input
          type="file"
          ref={fileInputRef}
          multiple // Allow multiple file selection.
          accept="image/*" // Accept only image files.
          onChange={handleFileSelect}
          className="hidden" // Hide the actual input.
        />
      </div>

      {/* Upload Messages */}
      {uploadMessage && (
        <Alert className="bg-green-50 border-green-200 text-green-700 mb-6">
          <CheckCircle className="h-5 w-5" />
          <AlertTitle>Success!</AlertTitle>
          <AlertDescription>{uploadMessage}</AlertDescription>
        </Alert>
      )}
      {uploadError && (
        <Alert variant="destructive" className="mb-6">
          <XCircle className="h-5 w-5" />
          <AlertTitle>Error!</AlertTitle>
          <AlertDescription>{uploadError}</AlertDescription>
        </Alert>
      )}

      {/* Uploaded Files List */}
      {files.length > 0 && (
        <div className="mb-8 space-y-4">
          <h3 className="font-serif text-2xl font-semibold text-brand-text">Uploaded Files ({files.length})</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {files.map((file) => (
              <Card key={file.id} className="bg-brand-background shadow-sm">
                <CardContent className="p-4 flex flex-col items-center text-center">
                  <div className="relative w-24 h-24 mb-2 rounded-lg overflow-hidden border border-brand-text/10">
                    {file.previewUrl ? (
                      <Image
                        src={file.previewUrl || "/placeholder.svg"}
                        alt={file.name}
                        fill
                        className="object-cover"
                      />
                    ) : (
                      <ImageIcon className="h-12 w-12 text-brand-text/50 absolute inset-0 m-auto" />
                    )}
                  </div>
                  <p className="text-sm font-medium text-brand-text truncate w-full px-2">{file.name}</p>
                  <p className="text-xs text-brand-text/70 mb-2">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  {file.status === "uploading" && (
                    <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                      <div className="bg-brand-cta h-2.5 rounded-full" style={{ width: `${file.progress}%` }}></div>
                    </div>
                  )}
                  {file.status === "completed" && (
                    <span className="text-green-600 text-sm flex items-center">
                      <CheckCircle className="h-4 w-4 mr-1" /> Uploaded
                    </span>
                  )}
                  {file.status === "failed" && (
                    <span className="text-red-600 text-sm flex items-center">
                      <XCircle className="h-4 w-4 mr-1" /> Failed
                    </span>
                  )}
                  {file.status === "pending" && (
                    <span className="text-brand-text/70 text-sm flex items-center">
                      <Loader2 className="h-4 w-4 mr-1 animate-spin" /> Pending
                    </span>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Proceed to Payment Button */}
      <Button
        size="lg"
        className="w-full bg-brand-cta hover:bg-brand-cta/90 text-white font-semibold py-6 text-lg shadow-soft-md"
        onClick={handleProceedToPayment}
        disabled={files.length === 0 || files.some((f) => f.status !== "completed")} // Disable if no files or not all completed.
      >
        Protect Memories & Proceed to Payment
      </Button>
    </div>
  )
}
