import Link from "next/link"
import { buttonVariants } from "@/components/ui/button" // Import buttonVariants
import { cn } from "@/lib/utils" // Import cn utility

export default function PaymentPage() {
  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h1 className="text-3xl font-bold mb-4">Payment Page</h1>
      <p className="mb-4">This is the payment page.</p>
      <Link
        href="/restore-old-photos"
        className={cn(
          buttonVariants({ variant: "default" }), // Apply default button styles
        )}
      >
        Back to Photo Upload
      </Link>
    </div>
  )
}
