// app/payment/PaymentPageClient.tsx
// This client component simulates a Stripe payment page.
// It includes input fields for card details and billing information,
// and a button to simulate payment submission.
// Placeholder: This is a mock-up and does not process real payments.

"use client" // Marks this component as a Client Component due to state and form handling.

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation" // Next.js router for navigation.
import { Button } from "@/components/ui/button" // Shadcn UI Button component.
import { Input } from "@/components/ui/input" // Shadcn UI Input component.
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card" // Shadcn UI Card components.
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert" // Shadcn UI Alert components for messages.
import { CreditCard, CheckCircle, XCircle } from "lucide-react" // Lucide React icons.

export default function PaymentPageClient() {
  const router = useRouter() // Initialize Next.js router.

  // State for form fields.
  const [formData, setFormData] = useState({
    cardNumber: "",
    expiryDate: "",
    cvc: "",
    nameOnCard: "",
    billingAddress: "",
    city: "",
    zipCode: "",
    country: "",
  })
  // State for loading status during payment simulation.
  const [isLoading, setIsLoading] = useState(false)
  // State for success message.
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  // State for error message.
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  // Handles changes to form input fields.
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }))
  }

  // Handles the simulated payment submission.
  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault() // Prevent default form submission.
    setIsLoading(true) // Set loading state.
    setSuccessMessage(null) // Clear previous messages.
    setErrorMessage(null)

    // Basic form validation (Placeholder).
    // In a real Stripe integration, client-side validation would be more robust
    // and often handled by Stripe's own elements (e.g., CardElement).
    const requiredFields = [
      "cardNumber",
      "expiryDate",
      "cvc",
      "nameOnCard",
      "billingAddress",
      "city",
      "zipCode",
      "country",
    ]
    const missingFields = requiredFields.filter((field) => !formData[field as keyof typeof formData])

    if (missingFields.length > 0) {
      setErrorMessage("Please fill in all required fields.")
      setIsLoading(false)
      return
    }

    // Placeholder Handoff: Stripe Payment Integration
    // In a real application, this is where you would integrate with Stripe.js:
    // 1. Collect card details securely using Stripe Elements.
    // 2. Create a PaymentMethod or Token on the client-side.
    // 3. Send the PaymentMethod/Token to your backend (Server Action/API route).
    // 4. Your backend would then create a PaymentIntent or Charge using Stripe's API.
    // 5. Handle confirmation and redirect based on the backend response.
    console.log("Simulating Stripe payment with data:", formData)
    await new Promise((resolve) => setTimeout(resolve, 2000)) // Simulate network delay for payment processing.

    // Simulate payment success or failure.
    const isPaymentSuccessful = Math.random() > 0.1 // 90% chance of success for demo.

    if (isPaymentSuccessful) {
      setSuccessMessage("Payment successful! Redirecting to download page...")
      // Handoff: Redirect to payment success page.
      router.push("/payment-success") // Redirect to the success page.
    } else {
      setErrorMessage("Payment failed. Please check your card details and try again.")
    }

    setIsLoading(false) // Reset loading state.
  }

  return (
    <div className="bg-brand-background min-h-screen py-16 pt-28">
      {" "}
      {/* pt-28 for header spacing */}
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-12">
            <h1 className="font-serif text-4xl lg:text-5xl font-normal text-brand-text mb-4">Complete Your Order</h1>
            <div className="w-32 h-px bg-brand-secondary mx-auto mb-6"></div>
            <p className="text-xl text-brand-text/80 max-w-2xl mx-auto leading-relaxed">
              Securely enter your payment details to finalize your photo restoration.
            </p>
          </div>

          {/* Payment Form Card */}
          <Card className="bg-white shadow-soft p-8">
            <CardHeader className="text-center mb-6">
              <CreditCard className="h-12 w-12 text-brand-cta mx-auto mb-4" />
              <CardTitle className="font-serif text-3xl text-brand-text">Payment Details</CardTitle>
              <CardDescription className="text-brand-text/70">
                <span className="font-semibold text-red-500">
                  This is a mock payment page for demonstration purposes only. No real transactions will occur.
                </span>
                <br />
                Your information is not stored.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePaymentSubmit} className="space-y-6">
                {/* Card Details Section */}
                <h3 className="font-serif text-2xl font-semibold text-brand-text mb-4">Card Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label htmlFor="cardNumber" className="block text-lg font-medium text-brand-text mb-2">
                      Card Number
                    </label>
                    <Input
                      type="text"
                      id="cardNumber"
                      placeholder="XXXX XXXX XXXX XXXX"
                      value={formData.cardNumber}
                      onChange={handleChange}
                      className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                      maxLength={19} // Max length for card number with spaces
                      disabled={isLoading}
                    />
                  </div>
                  <div>
                    <label htmlFor="expiryDate" className="block text-lg font-medium text-brand-text mb-2">
                      Expiry Date (MM/YY)
                    </label>
                    <Input
                      type="text"
                      id="expiryDate"
                      placeholder="MM/YY"
                      value={formData.expiryDate}
                      onChange={handleChange}
                      className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                      maxLength={5} // Max length for MM/YY
                      disabled={isLoading}
                    />
                  </div>
                  <div>
                    <label htmlFor="cvc" className="block text-lg font-medium text-brand-text mb-2">
                      CVC
                    </label>
                    <Input
                      type="text"
                      id="cvc"
                      placeholder="XXX"
                      value={formData.cvc}
                      onChange={handleChange}
                      className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                      maxLength={4} // Max length for CVC
                      disabled={isLoading}
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="nameOnCard" className="block text-lg font-medium text-brand-text mb-2">
                    Name on Card
                  </label>
                  <Input
                    type="text"
                    id="nameOnCard"
                    placeholder="Full Name"
                    value={formData.nameOnCard}
                    onChange={handleChange}
                    className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                    disabled={isLoading}
                  />
                </div>

                {/* Billing Information Section */}
                <h3 className="font-serif text-2xl font-semibold text-brand-text mb-4 mt-8">Billing Information</h3>
                <div>
                  <label htmlFor="billingAddress" className="block text-lg font-medium text-brand-text mb-2">
                    Billing Address
                  </label>
                  <Input
                    type="text"
                    id="billingAddress"
                    placeholder="Street Address"
                    value={formData.billingAddress}
                    onChange={handleChange}
                    className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                    disabled={isLoading}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="city" className="block text-lg font-medium text-brand-text mb-2">
                      City
                    </label>
                    <Input
                      type="text"
                      id="city"
                      placeholder="City"
                      value={formData.city}
                      onChange={handleChange}
                      className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                      disabled={isLoading}
                    />
                  </div>
                  <div>
                    <label htmlFor="zipCode" className="block text-lg font-medium text-brand-text mb-2">
                      Zip Code
                    </label>
                    <Input
                      type="text"
                      id="zipCode"
                      placeholder="XXXXX"
                      value={formData.zipCode}
                      onChange={handleChange}
                      className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                      disabled={isLoading}
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="country" className="block text-lg font-medium text-brand-text mb-2">
                    Country
                  </label>
                  <Input
                    type="text"
                    id="country"
                    placeholder="Country"
                    value={formData.country}
                    onChange={handleChange}
                    className="w-full border-brand-text/20 focus:border-brand-cta focus:ring-brand-cta text-lg"
                    disabled={isLoading}
                  />
                </div>

                {/* Messages for success/error */}
                {successMessage && (
                  <Alert className="bg-green-50 border-green-200 text-green-700">
                    <CheckCircle className="h-5 w-5" />
                    <AlertTitle>Success!</AlertTitle>
                    <AlertDescription>{successMessage}</AlertDescription>
                  </Alert>
                )}
                {errorMessage && (
                  <Alert variant="destructive">
                    <XCircle className="h-5 w-5" />
                    <AlertTitle>Error!</AlertTitle>
                    <AlertDescription>{errorMessage}</AlertDescription>
                  </Alert>
                )}

                {/* Payment Button */}
                <Button
                  type="submit"
                  className="w-full bg-brand-cta hover:bg-brand-cta/90 text-white font-semibold py-6 text-lg shadow-soft-md"
                  disabled={isLoading} // Disable button when loading.
                >
                  {isLoading ? "Processing Payment..." : "Pay Now"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
