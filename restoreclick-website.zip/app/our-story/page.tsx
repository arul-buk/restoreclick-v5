// app/our-story/page.tsx
// This page tells the comprehensive "Our Story" of RestoreClick,
// detailing its origins, mission, and the people behind the service.
// It's a Server Component that provides static content.

import type { Metadata } from "next"
import Image from "next/image" // Next.js Image component for optimized images.

// Metadata for the "Our Story" page, used for SEO and browser tab title.
export const metadata: Metadata = {
  title: "Our Story | RestoreClick",
  description: "Discover the passion and precision behind RestoreClick's mission to preserve your family memories.",
}

// OurStoryPage component renders the static content of the story.
export default function OurStoryPage() {
  return (
    // Main container for the page, applying brand background and text colors, and ensuring minimum height.
    <div className="bg-brand-background text-brand-text min-h-screen pt-20">
      {" "}
      {/* pt-20 for header spacing */}
      {/* Hero section for the story page */}
      <section className="relative w-full h-[400px] md:h-[500px] flex items-center justify-center text-center text-white overflow-hidden">
        <Image
          src="/public/images/our-story-hero.jpg" // Static image asset for the hero background.
          alt="Vintage photographs being restored"
          fill // Fills the parent container.
          className="object-cover absolute inset-0 z-0 opacity-70" // Darken for text contrast.
          priority // Prioritize loading.
        />
        <div className="absolute inset-0 bg-brand-text/50 z-10" /> {/* Overlay for text readability */}
        <div className="relative z-20 p-6 container mx-auto">
          <h1 className="font-serif text-5xl md:text-7xl font-bold mb-4">Our Story</h1>
          <p className="font-sans text-lg md:text-xl max-w-3xl mx-auto">
            The passion and precision behind preserving your most cherished memories.
          </p>
        </div>
      </section>
      {/* Main content of the story */}
      <div className="container mx-auto px-6 py-16 max-w-4xl">
        <article className="prose prose-lg lg:prose-xl mx-auto text-brand-text prose-headings:font-serif prose-headings:text-brand-text prose-a:text-brand-cta prose-a:hover:text-brand-cta/80 prose-strong:text-brand-text">
          <h2>The Genesis of RestoreClick</h2>
          <p>
            RestoreClick was born from a simple, yet profound realization: the irreplaceable value of family
            photographs. Our founder, Lily Chen, grew up poring over her grandmother's old photo albums. Each faded
            snapshot, each creased corner, told a story – a tangible link to a past that shaped her present. But she
            also saw the ravages of time: colors bleeding, tears marring faces, and the slow, inevitable decay that
            threatened to erase these precious visual histories.
          </p>
          <div className="relative aspect-[16/9] w-full my-8 rounded-lg overflow-hidden shadow-soft">
            <Image
              src="/public/images/our-story-grandma.jpg" // Static image asset.
              alt="Old family photo being held"
              fill
              className="object-cover"
            />
          </div>
          <p>
            This personal connection ignited a passion. Lily, a digital artist by trade, began experimenting with
            restoration techniques, driven by a desire to bring these fading memories back to life. What started as a
            personal quest soon blossomed into a mission: to offer a service that combines artistic precision with
            cutting-edge technology, making professional photo restoration accessible to everyone who values their
            family's legacy.
          </p>

          <h2>Our Philosophy: Digital Artisans, Memory Concierges</h2>
          <p>
            At RestoreClick, we don't just "fix" photos; we meticulously restore them. We see ourselves as digital
            artisans, treating each image as a unique piece of art. Our process is a blend of human expertise and
            advanced digital tools, ensuring that every detail is carefully considered and every imperfection addressed
            with the utmost care.
          </p>
          <div className="relative aspect-[16/9] w-full my-8 rounded-lg overflow-hidden shadow-soft">
            <Image
              src="/public/images/our-story-artisan.png" // Static image asset.
              alt="Digital artisan working on photo restoration"
              fill
              className="object-cover"
            />
          </div>
          <p>
            We also act as your "memory concierges." We understand that your time is precious, and the process of
            digitizing and restoring old photos can seem daunting. That's why we've designed our service to be
            effortless and seamless. From the moment you entrust us with your images, our team handles everything,
            providing a white-glove experience that saves you invaluable time and delivers museum-quality results.
          </p>

          <h2>Preserving Legacy, One Photo at a Time</h2>
          <p>
            Our ultimate goal is to help you transform faded memories into timeless art. Whether it's a cherished
            wedding photo, a portrait of a beloved ancestor, or a snapshot from a forgotten vacation, each restored
            image becomes a vibrant digital heirloom, ready to be displayed, shared, and passed down through
            generations.
          </p>
          <div className="relative aspect-[16/9] w-full my-8 rounded-lg overflow-hidden shadow-soft">
            <Image
              src="/public/images/our-story-legacy.jpg" // Static image asset.
              alt="Family looking at old photo album"
              fill
              className="object-cover"
            />
          </div>
          <p>
            We believe that every family's history is a masterpiece worth preserving. Join us in safeguarding your
            legacy and ensuring that the stories held within your photographs continue to inspire and connect for years
            to come.
          </p>
          <div className="text-right mt-12">
            <p className="font-serif text-2xl font-semibold text-brand-text">Lily Chen</p>
            <Image
              src="/public/images/lily-signature.png" // Static image asset for Lily's signature.
              alt="Lily Chen's Signature"
              width={150}
              height={50}
              className="mt-2 mx-auto md:mx-0"
            />
            <p className="text-brand-text/70">Founder, RestoreClick</p>
          </div>
        </article>
      </div>
    </div>
  )
}
