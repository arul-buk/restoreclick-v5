// app/page.tsx
// This is the main homepage for the RestoreClick application.
// It's a Server Component that orchestrates various landing page sections.

import type { Metadata } from "next"
// Importing various sections that compose the homepage.
// These components are responsible for rendering specific parts of the landing page.
import EditorialHeroSection from "@/components/landing/editorial-hero-section"
import StoryIntroSection from "@/components/landing/story-intro-section"
import CraftShowcaseSection from "@/components/landing/craft-showcase-section"
import ArtisanProcessSection from "@/components/landing/artisan-process-section"
import FeaturedTestimonialSection from "@/components/landing/featured-testimonial-section"
import GentleInvitationSection from "@/components/landing/gentle-invitation-section"

// Metadata for the homepage, used for SEO and browser tab title.
export const metadata: Metadata = {
  title: "RestoreClick | Your Legacy, Perfectly Preserved",
  description:
    "A white-glove digital restoration service for your most cherished family photographs. Effortless process, museum-quality results.",
}

// HomePage component renders the main structure of the landing page.
export default function HomePage() {
  return (
    // Main container for the entire page, applying global brand background and text colors.
    <div className="bg-brand-background text-brand-text font-sans">
      <main>
        {/* Each section is wrapped in a <section> tag with a unique ID for smooth scrolling navigation. */}

        {/* Hero Section: The prominent top section with a video background and main call to action. */}
        <section id="hero">
          <EditorialHeroSection />
        </section>

        {/* Story Introduction Section: Introduces the brand's story or ethos. */}
        <section id="story">
          <StoryIntroSection />
        </section>

        {/* Craft Showcase Section: Displays before-and-after examples of photo restoration. */}
        <section id="showcase">
          <CraftShowcaseSection />
        </section>

        {/* Artisan Process Section: Explains the step-by-step process of photo restoration. */}
        <section id="process">
          <ArtisanProcessSection />
        </section>

        {/* Featured Testimonial Section: Highlights a key customer testimonial. */}
        <section id="testimonials">
          <FeaturedTestimonialSection />
        </section>

        {/* Gentle Invitation Section: A final call to action to engage with the service. */}
        <section id="invitation">
          <GentleInvitationSection />
        </section>
      </main>
    </div>
  )
}
