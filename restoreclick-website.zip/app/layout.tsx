import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google" // Importing Google Font for body text.
import ClientLayout from "./clientLayout" // Client-side layout component.

// Initialize the Inter font with Latin subsets.
const inter = Inter({ subsets: ["latin"] })

// Metadata for the entire application, used for global SEO and browser tab title.
export const metadata: Metadata = {
  title: "RestoreClick",
  description: "White-glove digital restoration for your most cherished photographs.",
    generator: 'v0.dev'
}

// RootLayout component wraps the entire application.
// It receives `children` which represents the content of the current page or nested layout.
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    // ClerkProvider wraps the entire application to make Clerk's authentication
    // context available to all client components. This fixes the "useUser can only be used
    // within the <ClerkProvider /> component" error by ensuring the provider is at the root.
    <html lang="en">
      {/* Body tag applies the Inter font class globally. */}
      <body className={inter.className}>
        {/* ClientLayout wraps the children, providing client-side features like
          the header, footer, and mobile menu, which need access to browser APIs. */}
        <ClientLayout>{children}</ClientLayout>
      </body>
    </html>
  )
}


import './globals.css'